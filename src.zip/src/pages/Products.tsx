import React, { useState, useEffect } from 'react';
import { Plus, Search, Package, ChevronLeft, ChevronRight, Edit2, Trash2 } from 'lucide-react';
import { Product, Category, Subcategory } from '../types';
import ProductModal from '../components/ProductModal';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { MOCK_CATEGORIES, MOCK_SUBCATEGORIES, INITIAL_PRODUCTS } from '../services/mockData';

const Products: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';

  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(MOCK_CATEGORIES);
  const [allSubcategories, setAllSubcategories] = useState<Subcategory[]>(MOCK_SUBCATEGORIES);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Filter states
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterSubcategory, setFilterSubcategory] = useState('');
  const [page, setPage] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    let result = [...products];

    if (search) {
      result = result.filter(p => 
        p.name.toLowerCase().includes(search.toLowerCase()) || 
        p.sku.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (filterCategory) {
      result = result.filter(p => Number(p.category_id) === Number(filterCategory));
    }

    if (filterSubcategory) {
      result = result.filter(p => Number(p.subcategory_id) === Number(filterSubcategory));
    }

    setFilteredProducts(result);
    setPage(1);
  }, [products, search, filterCategory, filterSubcategory]);

  useEffect(() => {
    if (filterCategory) {
      const filtered = allSubcategories.filter(
        sub => sub.category_id === Number(filterCategory) && sub.parent_id === null
      );
      setSubcategories(filtered);
    } else {
      setSubcategories([]);
    }
  }, [filterCategory, allSubcategories]);

  const handleAddCategory = (name_ar: string, name_en: string) => {
    const newCat: Category = {
      id: Math.max(0, ...categories.map(c => c.id)) + 1,
      name_ar,
      name_en,
      slug: name_en.toLowerCase().replace(/\s+/g, '-')
    };
    setCategories(prev => [...prev, newCat]);
    toast.success(t('category_added_successfully'));
    return newCat;
  };

  const handleEditCategory = (id: number, name_ar: string, name_en: string) => {
    setCategories(prev => prev.map(cat => cat.id === id ? { ...cat, name_ar, name_en } : cat));
    toast.success(t('category_updated_successfully'));
  };

  const handleDeleteCategory = (id: number) => {
    setCategories(prev => prev.filter(cat => cat.id !== id));
    setAllSubcategories(prev => prev.filter(sub => sub.category_id !== id));
    setProducts(prev => prev.map(p => Number(p.category_id) === id ? { ...p, category_id: '', subcategory_id: '', child_subcategory_id: '' } : p));
    toast.success(t('category_deleted_successfully'));
  };

  const handleAddSubcategory = (name_ar: string, name_en: string, category_id: number, parent_id: number | null = null) => {
    const newSub: Subcategory = {
      id: Math.max(0, ...allSubcategories.map(s => s.id)) + 1,
      name_ar,
      name_en,
      category_id,
      parent_id,
      slug: name_en.toLowerCase().replace(/\s+/g, '-')
    };
    setAllSubcategories(prev => [...prev, newSub]);
    toast.success(t('subcategory_added_successfully'));
    return newSub;
  };

  const handleEditSubcategory = (id: number, name_ar: string, name_en: string) => {
    setAllSubcategories(prev => prev.map(sub => sub.id === id ? { ...sub, name_ar, name_en } : sub));
    toast.success(t('subcategory_updated_successfully'));
  };

  const handleDeleteSubcategory = (id: number) => {
    setAllSubcategories(prev => prev.filter(sub => sub.id !== id && sub.parent_id !== id));
    setProducts(prev => prev.map(p => Number(p.subcategory_id) === id || Number(p.child_subcategory_id) === id ? { ...p, subcategory_id: '', child_subcategory_id: '' } : p));
    toast.success(t('subcategory_deleted_successfully'));
  };

  const handleSave = (productData: Product) => {
    if (productData.id) {
      // Update
      setProducts(prev => prev.map(p => p.id === productData.id ? productData : p));
      toast.success(t('product_updated_successfully'));
    } else {
      // Create
      const newProduct = {
        ...productData,
        id: Math.max(0, ...products.map(p => p.id || 0)) + 1,
        created_at: new Date().toISOString()
      };
      setProducts(prev => [newProduct, ...prev]);
      toast.success(t('product_added_successfully'));
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (!window.confirm(t('delete_confirmation'))) return;
    setProducts(prev => prev.filter(p => p.id !== id));
    toast.success(t('product_deleted_successfully'));
  };

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const paginatedProducts = filteredProducts.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const getCategoryName = (id: number | '') => {
    const cat = categories.find(c => c.id === Number(id));
    return isRtl ? cat?.name_ar : cat?.name_en;
  };

  const getSubcategoryName = (id: number | '') => {
    const sub = allSubcategories.find(s => s.id === Number(id));
    return isRtl ? sub?.name_ar : sub?.name_en;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{t('products')}</h1>
          <p className="text-slate-500 dark:text-slate-400">{t('إدارة وتتبع كافة أجهزة ومنتجات الأسطول')}</p>
        </div>
        <button
          onClick={() => {
            setSelectedProduct(null);
            setIsModalOpen(true);
          }}
          className="btn-primary flex items-center gap-2"
        >
          <Plus size={20} />
          {t('إضافة منتج جديد')}
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder={t('بحث باسم المنتج أو SKU...')}
            className="input-field pl-10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="input-field"
          value={filterCategory}
          onChange={(e) => {
            setFilterCategory(e.target.value);
            setFilterSubcategory('');
          }}
        >
          <option value="">{t('كل التصنيفات')}</option>
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{isRtl ? cat.name_ar : cat.name_en}</option>
          ))}
        </select>
        <select
          className="input-field"
          value={filterSubcategory}
          onChange={(e) => setFilterSubcategory(e.target.value)}
          disabled={!filterCategory}
        >
          <option value="">{t('كل التصنيفات الفرعية')}</option>
          {subcategories.map(sub => (
            <option key={sub.id} value={sub.id}>{isRtl ? sub.name_ar : sub.name_en}</option>
          ))}
        </select>
        <div className="flex items-center justify-end text-sm text-slate-500">
          {t('إجمالي المنتجات')}: {filteredProducts.length}
        </div>
      </div>

      {/* Products Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300">{t('المنتج')}</th>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300">{t('التصنيف')}</th>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300">{t('SKU')}</th>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300">{t('الوزن')}</th>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300">{t('تاريخ الإضافة')}</th>
                <th className="p-4 font-bold text-slate-700 dark:text-slate-300 text-center">{t('إجراءات')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="p-4"><div className="h-12 bg-slate-100 dark:bg-slate-800 rounded-lg"></div></td>
                  </tr>
                ))
              ) : paginatedProducts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-500">
                    <Package size={48} className="mx-auto mb-4 opacity-20" />
                    {t('لا توجد منتجات مطابقة للبحث')}
                  </td>
                </tr>
              ) : (
                paginatedProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 overflow-hidden flex-shrink-0">
                          {product.image_url ? (
                            <img src={product.image_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-400"><Package size={20} /></div>
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">{product.name}</div>
                          <div className="text-xs text-slate-500">{product.subtitle}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="text-sm">
                        <span className="px-2 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                          {getCategoryName(product.category_id)}
                        </span>
                        {product.subcategory_id && (
                          <span className="mx-1 text-slate-400">›</span>
                        )}
                        <span className="text-slate-500 text-xs">
                          {getSubcategoryName(product.subcategory_id)}
                        </span>
                      </div>
                    </td>
                    <td className="p-4 text-sm font-mono text-slate-600 dark:text-slate-400">{product.sku || '-'}</td>
                    <td className="p-4 text-sm text-slate-600 dark:text-slate-400">{product.weight ? `${product.weight} كجم` : '-'}</td>
                    <td className="p-4 text-sm text-slate-500">
                      {product.created_at ? new Date(product.created_at).toLocaleDateString(isRtl ? 'ar-SA' : 'en-US') : '-'}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsModalOpen(true);
                          }}
                          className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title={t('تعديل')}
                        >
                          <Edit2 size={18} />
                        </button>
                        <button
                          onClick={() => product.id && handleDelete(product.id)}
                          className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                          title={t('حذف')}
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 bg-slate-50 dark:bg-slate-800/30 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="text-sm text-slate-500">
              {t('صفحة')} {page} {t('من')} {totalPages}
            </div>
            <div className="flex gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 hover:bg-white dark:hover:bg-slate-800 transition-colors"
              >
                {isRtl ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
              </button>
              <button
                disabled={page === totalPages}
                onClick={() => setPage(p => p + 1)}
                className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-30 hover:bg-white dark:hover:bg-slate-800 transition-colors"
              >
                {isRtl ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
              </button>
            </div>
          </div>
        )}
      </div>

      <ProductModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
        product={selectedProduct}
        categories={categories}
        subcategories={allSubcategories}
        onAddCategory={handleAddCategory}
        onEditCategory={handleEditCategory}
        onDeleteCategory={handleDeleteCategory}
        onAddSubcategory={handleAddSubcategory}
        onEditSubcategory={handleEditSubcategory}
        onDeleteSubcategory={handleDeleteSubcategory}
      />
    </div>
  );
};

export default Products;
