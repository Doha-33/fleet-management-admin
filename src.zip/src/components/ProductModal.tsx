import React, { useState, useEffect } from 'react';
import { X, Save, Image as ImageIcon, Info, Globe, Settings, Package, Truck, Barcode, List, FileText, CheckCircle2 } from 'lucide-react';
import { Product, Category, Subcategory } from '../types';
import { useTranslation } from 'react-i18next';

interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: Product) => void;
  product?: Product | null;
  categories: Category[];
  subcategories: Subcategory[];
  onAddCategory: (name_ar: string, name_en: string) => Category;
  onEditCategory: (id: number, name_ar: string, name_en: string) => void;
  onDeleteCategory: (id: number) => void;
  onAddSubcategory: (name_ar: string, name_en: string, category_id: number, parent_id: number | null) => Subcategory;
  onEditSubcategory: (id: number, name_ar: string, name_en: string) => void;
  onDeleteSubcategory: (id: number) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  product, 
  categories, 
  subcategories: allSubcategories,
  onAddCategory,
  onEditCategory,
  onDeleteCategory,
  onAddSubcategory,
  onEditSubcategory,
  onDeleteSubcategory
}) => {
  const { t, i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';

  const [formData, setFormData] = useState<Product>({
    name: '',
    category_id: '',
    subcategory_id: '',
    child_subcategory_id: '',
    weight: '',
    sku: '',
    mpn: '',
    gtin: '',
    price: '',
    cost_price: '',
    reduced_price: '',
    max_qty_per_customer: '',
    subtitle: '',
    promo_title: '',
    brand: '',
    description: '',
    image_url: '',
    seo_title: '',
    seo_url: '',
    seo_description: '',
    requires_shipping: true,
    is_quantity_determined: true,
    show_in_store: true,
    attach_file: false,
    allow_notes: false,
    display_channels: {
      meta: true,
      google: true,
      snapchat: true,
      tiktok: true,
    }
  });

  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [childSubcategories, setChildSubcategories] = useState<Subcategory[]>([]);
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [isEditingCategory, setIsEditingCategory] = useState(false);
  const [isAddingSubcategory, setIsAddingSubcategory] = useState(false);
  const [isEditingSubcategory, setIsEditingSubcategory] = useState(false);
  const [quickAddName, setQuickAddName] = useState('');

  useEffect(() => {
    if (product) {
      setFormData({
        ...product,
        display_channels: product.display_channels || {
          meta: true,
          google: true,
          snapchat: true,
          tiktok: true,
        }
      });
    } else {
      setFormData({
        name: '',
        category_id: '',
        subcategory_id: '',
        child_subcategory_id: '',
        weight: '',
        sku: '',
        mpn: '',
        gtin: '',
        price: '',
        cost_price: '',
        reduced_price: '',
        max_qty_per_customer: '',
        subtitle: '',
        promo_title: '',
        brand: '',
        description: '',
        image_url: '',
        seo_title: '',
        seo_url: '',
        seo_description: '',
        requires_shipping: true,
        is_quantity_determined: true,
        show_in_store: true,
        attach_file: false,
        allow_notes: false,
        display_channels: {
          meta: true,
          google: true,
          snapchat: true,
          tiktok: true,
        }
      });
    }
  }, [product, isOpen]);

  useEffect(() => {
    if (formData.category_id) {
      const filtered = allSubcategories.filter(
        sub => Number(sub.category_id) === Number(formData.category_id) && sub.parent_id === null
      );
      setSubcategories(filtered);
    } else {
      setSubcategories([]);
      setFormData(prev => ({ ...prev, subcategory_id: '', child_subcategory_id: '' }));
    }
  }, [formData.category_id, allSubcategories]);

  useEffect(() => {
    if (formData.subcategory_id) {
      const filtered = allSubcategories.filter(
        sub => sub.parent_id === Number(formData.subcategory_id)
      );
      setChildSubcategories(filtered);
    } else {
      setChildSubcategories([]);
      setFormData(prev => ({ ...prev, child_subcategory_id: '' }));
    }
  }, [formData.subcategory_id, allSubcategories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      const isIdField = ['category_id', 'subcategory_id', 'child_subcategory_id', 'max_qty_per_customer'].includes(name);
      const finalValue = isIdField && value !== '' ? Number(value) : value;
      setFormData(prev => ({ ...prev, [name]: finalValue }));
    }
  };

  const handleQuickAddCategory = () => {
    if (quickAddName.trim()) {
      if (isEditingCategory && formData.category_id) {
        onEditCategory(Number(formData.category_id), quickAddName, quickAddName);
        setIsEditingCategory(false);
      } else {
        const newCat = onAddCategory(quickAddName, quickAddName);
        setFormData(prev => ({ ...prev, category_id: newCat.id }));
      }
      setQuickAddName('');
      setIsAddingCategory(false);
    }
  };

  const handleDeleteCategory = () => {
    if (formData.category_id && confirm(t('delete_confirmation'))) {
      onDeleteCategory(Number(formData.category_id));
      setFormData(prev => ({ ...prev, category_id: '', subcategory_id: '', child_subcategory_id: '' }));
    }
  };

  const handleQuickAddSubcategory = () => {
    if (!formData.category_id) {
      alert(t('select_main_first'));
      return;
    }
    if (quickAddName.trim()) {
      if (isEditingSubcategory && formData.subcategory_id) {
        onEditSubcategory(Number(formData.subcategory_id), quickAddName, quickAddName);
        setIsEditingSubcategory(false);
      } else {
        const newSub = onAddSubcategory(quickAddName, quickAddName, Number(formData.category_id), null);
        setFormData(prev => ({ ...prev, subcategory_id: newSub.id }));
      }
      setQuickAddName('');
      setIsAddingSubcategory(false);
    }
  };

  const handleDeleteSubcategory = () => {
    if (formData.subcategory_id && confirm(t('delete_confirmation'))) {
      onDeleteSubcategory(Number(formData.subcategory_id));
      setFormData(prev => ({ ...prev, subcategory_id: '', child_subcategory_id: '' }));
    }
  };

  const handleChannelChange = (channel: keyof NonNullable<Product['display_channels']>) => {
    setFormData(prev => ({
      ...prev,
      display_channels: {
        ...prev.display_channels!,
        [channel]: !prev.display_channels![channel]
      }
    }));
  };

  const insertFormat = (tag: string) => {
    const textarea = document.querySelector('textarea[name="description"]') as HTMLTextAreaElement;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const before = text.substring(0, start);
    const after = text.substring(end, text.length);
    const selection = text.substring(start, end);
    const newText = `${before}<${tag}>${selection}</${tag}>${after}`;
    setFormData(prev => ({ ...prev, description: newText }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
              <X size={20} className="text-slate-600 dark:text-slate-400" />
            </button>
            <h2 className="text-lg font-bold text-primary dark:text-slate-200">
              {product ? `${t('product_data')} (${product.name})` : t('add_new_product')}
            </h2>
          </div>
          <div className="flex gap-2">
            <button className="p-2 text-slate-400 hover:text-slate-600"><Settings size={20} /></button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
          <div className="space-y-8">
            {/* Category Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('main_category')}</label>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-2">
                    <select
                      name="category_id"
                      value={formData.category_id}
                      onChange={handleChange}
                      className="input-field flex-1"
                      required
                    >
                      <option value="">{t('select_category')}</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{isRtl ? cat.name_ar : cat.name_en}</option>
                      ))}
                    </select>
                    <div className="flex gap-1">
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsAddingCategory(!isAddingCategory);
                          setIsEditingCategory(false);
                          setIsAddingSubcategory(false);
                          setQuickAddName('');
                        }}
                        className="px-3 py-2 bg-primary/10 text-primary rounded-xl text-[10px] font-bold hover:bg-primary/20 transition-colors border border-primary/20"
                      >
                        {isAddingCategory && !isEditingCategory ? t('cancel') : t('add_category')}
                      </button>
                      {formData.category_id && (
                        <>
                          <button 
                            type="button" 
                            onClick={() => {
                              const cat = categories.find(c => c.id === Number(formData.category_id));
                              setQuickAddName(isRtl ? cat?.name_ar || '' : cat?.name_en || '');
                              setIsAddingCategory(true);
                              setIsEditingCategory(true);
                              setIsAddingSubcategory(false);
                            }}
                            className="px-3 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl text-[10px] font-bold hover:bg-blue-100 transition-colors border border-blue-100 dark:border-blue-800"
                          >
                            {t('edit')}
                          </button>
                          <button 
                            type="button" 
                            onClick={handleDeleteCategory}
                            className="px-3 py-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-xl text-[10px] font-bold hover:bg-red-100 transition-colors border border-red-100 dark:border-red-800"
                          >
                            {t('delete')}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                  {isAddingCategory && (
                    <div className="flex gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                      <input
                        type="text"
                        value={quickAddName}
                        onChange={(e) => setQuickAddName(e.target.value)}
                        placeholder={isEditingCategory ? t('edit_category') : t('enter_category_name')}
                        className="input-field flex-1 text-sm"
                        autoFocus
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleQuickAddCategory())}
                      />
                      <button
                        type="button"
                        onClick={handleQuickAddCategory}
                        className="px-4 py-2 bg-primary text-white rounded-xl text-xs font-bold hover:bg-primary-dark transition-colors"
                      >
                        {t('save')}
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('subcategory')}</label>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-2">
                    <select
                      name="subcategory_id"
                      value={formData.subcategory_id}
                      onChange={handleChange}
                      className="input-field flex-1"
                      disabled={!formData.category_id}
                    >
                      <option value="">{t('select_subcategory')}</option>
                      {subcategories.map(sub => (
                        <option key={sub.id} value={sub.id}>{isRtl ? sub.name_ar : sub.name_en}</option>
                      ))}
                    </select>
                    <div className="flex gap-1">
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsAddingSubcategory(!isAddingSubcategory);
                          setIsEditingSubcategory(false);
                          setIsAddingCategory(false);
                          setQuickAddName('');
                        }}
                        disabled={!formData.category_id}
                        className="px-3 py-2 bg-primary/10 text-primary rounded-xl text-[10px] font-bold hover:bg-primary/20 transition-colors border border-primary/20 disabled:opacity-50"
                      >
                        {isAddingSubcategory && !isEditingSubcategory ? t('cancel') : t('add_subcategory')}
                      </button>
                      {formData.subcategory_id && (
                        <>
                          <button 
                            type="button" 
                            onClick={() => {
                              const sub = allSubcategories.find(s => s.id === Number(formData.subcategory_id));
                              setQuickAddName(isRtl ? sub?.name_ar || '' : sub?.name_en || '');
                              setIsAddingSubcategory(true);
                              setIsEditingSubcategory(true);
                              setIsAddingCategory(false);
                            }}
                            className="px-3 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl text-[10px] font-bold hover:bg-blue-100 transition-colors border border-blue-100 dark:border-blue-800"
                          >
                            {t('edit')}
                          </button>
                          <button 
                            type="button" 
                            onClick={handleDeleteSubcategory}
                            className="px-3 py-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-xl text-[10px] font-bold hover:bg-red-100 transition-colors border border-red-100 dark:border-red-800"
                          >
                            {t('delete')}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                  {isAddingSubcategory && (
                    <div className="flex gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                      <input
                        type="text"
                        value={quickAddName}
                        onChange={(e) => setQuickAddName(e.target.value)}
                        placeholder={isEditingSubcategory ? t('edit_subcategory') : t('enter_subcategory_name')}
                        className="input-field flex-1 text-sm"
                        autoFocus
                        onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleQuickAddSubcategory())}
                      />
                      <button
                        type="button"
                        onClick={handleQuickAddSubcategory}
                        className="px-4 py-2 bg-primary text-white rounded-xl text-xs font-bold hover:bg-primary-dark transition-colors"
                      >
                        {t('save')}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('product_name')}</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="input-field"
                  required
                  placeholder={t('enter_product_name')}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('promo_title')}</label>
                <input
                  type="text"
                  name="promo_title"
                  value={formData.promo_title}
                  onChange={handleChange}
                  className="input-field"
                  placeholder={t('promo_title')}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('brand')}</label>
                <input
                  type="text"
                  name="brand"
                  value={formData.brand}
                  onChange={handleChange}
                  className="input-field"
                  placeholder={t('brand')}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('subtitle')}</label>
                <input
                  type="text"
                  name="subtitle"
                  value={formData.subtitle}
                  onChange={handleChange}
                  className="input-field"
                  placeholder={t('subtitle')}
                />
              </div>
            </div>

            {/* Price Section (Optional) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('price')}</label>
                <input
                  type="number"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('cost_price')}</label>
                <input
                  type="number"
                  name="cost_price"
                  value={formData.cost_price}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('reduced_price')}</label>
                <input
                  type="number"
                  name="reduced_price"
                  value={formData.reduced_price}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="0.00"
                />
              </div>
            </div>

            {/* Shipping & Weight */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('requires_shipping')}</label>
                <select
                  name="requires_shipping"
                  value={formData.requires_shipping ? 'true' : 'false'}
                  onChange={(e) => setFormData(prev => ({ ...prev, requires_shipping: e.target.value === 'true' }))}
                  className="input-field"
                >
                  <option value="true">نعم، يتطلب شحن</option>
                  <option value="false">لا، لا يتطلب شحن</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('product_weight')}</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Truck className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                      type="text"
                      name="weight"
                      value={formData.weight}
                      onChange={handleChange}
                      className="input-field pr-10"
                      placeholder="0.0"
                    />
                  </div>
                  <select className="input-field w-24 bg-slate-50 dark:bg-slate-800">
                    <option>كجم</option>
                    <option>جم</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Codes & Quantity */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('sku_storage')}</label>
                <div className="relative">
                  <Barcode className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    name="sku"
                    value={formData.sku}
                    onChange={handleChange}
                    className="input-field pr-10"
                    placeholder="SKU-123"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('quantity_determination')}</label>
                <select
                  name="is_quantity_determined"
                  value={formData.is_quantity_determined ? 'true' : 'false'}
                  onChange={(e) => setFormData(prev => ({ ...prev, is_quantity_determined: e.target.value === 'true' }))}
                  className="input-field"
                >
                  <option value="true">تفعيل خيار تحديد الكمية</option>
                  <option value="false">كمية غير محدودة</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('max_qty')}</label>
                <input
                  type="number"
                  name="max_qty_per_customer"
                  value={formData.max_qty_per_customer}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="10"
                />
              </div>
            </div>

            {/* Display Channels */}
            <div className="space-y-4 pt-6 border-t border-slate-100 dark:border-slate-800">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('display_channels')}</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {(['meta', 'google', 'snapchat', 'tiktok'] as const).map(channel => (
                  <label key={channel} className="flex items-center gap-3 p-3 border border-slate-200 dark:border-slate-800 rounded-xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                    <input
                      type="checkbox"
                      checked={formData.display_channels?.[channel]}
                      onChange={() => handleChannelChange(channel)}
                      className="w-5 h-5 rounded border-slate-300 text-primary focus:ring-primary"
                    />
                    <span className="text-sm font-bold capitalize text-slate-700 dark:text-slate-300">{channel}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Description (Rich Text Editor) */}
            <div className="space-y-3 pt-6 border-t border-slate-100 dark:border-slate-800">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('description')}</label>
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                <div className="bg-slate-50 dark:bg-slate-800/50 p-2 border-b border-slate-200 dark:border-slate-800 flex flex-wrap gap-2">
                  <button type="button" onClick={() => insertFormat('b')} className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-400 font-bold">B</button>
                  <button type="button" onClick={() => insertFormat('i')} className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-400 italic">I</button>
                  <button type="button" onClick={() => insertFormat('u')} className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-slate-600 dark:text-slate-400 underline">U</button>
                  <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1"></div>
                  <button type="button" onClick={() => insertFormat('h1')} className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-xs font-bold">H1</button>
                  <button type="button" onClick={() => insertFormat('h2')} className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded text-xs font-bold">H2</button>
                  <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1"></div>
                  <button type="button" className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded"><ImageIcon size={16} /></button>
                </div>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={8}
                  className="w-full p-4 bg-transparent focus:outline-none resize-none dark:text-white custom-scrollbar"
                  placeholder={t('enter_product_description')}
                />
              </div>
            </div>

            {/* Image URL */}
            <div className="space-y-4 pt-6 border-t border-slate-100 dark:border-slate-800">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('image')}</label>
              <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl bg-slate-50 dark:bg-slate-800/20 hover:bg-slate-100 transition-colors cursor-pointer group relative">
                {formData.image_url ? (
                  <div className="relative w-48 h-48">
                    <img src={formData.image_url} alt="Preview" className="w-full h-full object-cover rounded-xl" />
                    <button 
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, image_url: '' }))}
                      className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full shadow-lg"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <ImageIcon className="text-primary" size={32} />
                    </div>
                    <p className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('add_image_video')}</p>
                    <p className="text-xs text-slate-400 mt-1">PNG, JPG, MP4 up to 10MB</p>
                  </div>
                )}
                <input
                  type="text"
                  name="image_url"
                  value={formData.image_url}
                  onChange={handleChange}
                  className="mt-4 input-field text-center"
                  placeholder="أو أدخل رابط الصورة هنا"
                />
              </div>
            </div>

            {/* SEO Section */}
            <div className="space-y-6 pt-8 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-primary dark:text-slate-200 flex items-center gap-2">
                  {t('seo_settings')}
                  <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full uppercase font-bold">برو</span>
                </h3>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('page_title')}</label>
                  <div className="relative">
                    <FileText className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                      type="text"
                      name="seo_title"
                      value={formData.seo_title}
                      onChange={handleChange}
                      className="input-field pr-10"
                      placeholder={t('page_title')}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('page_url')}</label>
                  <div className="relative">
                    <Globe className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                      type="text"
                      name="seo_url"
                      value={formData.seo_url}
                      onChange={handleChange}
                      className="input-field pr-10"
                      placeholder="https://salla.sa/..."
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300">{t('page_description')}</label>
                  <textarea
                    name="seo_description"
                    value={formData.seo_description}
                    onChange={handleChange}
                    rows={3}
                    className="input-field"
                    placeholder={t('page_description')}
                  />
                </div>
              </div>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            {t('cancel')}
          </button>
          <button
            onClick={handleSubmit}
            className="bg-primary hover:bg-primary-dark text-white px-10 py-2.5 rounded-xl font-bold shadow-lg shadow-primary/20 flex items-center gap-2 transition-all active:scale-95"
          >
            <CheckCircle2 size={20} />
            {t('save_product')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;
