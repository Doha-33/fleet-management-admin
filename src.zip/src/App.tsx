import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import DashboardLayout from './layouts/DashboardLayout';
import Dashboard from './pages/Dashboard';
import Devices from './pages/Devices';
import Services from './pages/Services';
import Blog from './pages/Blog';
import Requests from './pages/Requests';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import ActivityLogs from './pages/ActivityLogs';
import Products from './pages/Products';
import Login from './pages/Login';
import { Toaster } from 'sonner';
import './i18n/config';
import { useTranslation } from 'react-i18next';

export default function App() {
  const { i18n } = useTranslation();

  // Handle RTL setup globally
  useEffect(() => {
    const lang = i18n.language;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [i18n.language]);

  return (
    <ThemeProvider>
      <AuthProvider>
        <Toaster position="top-right" richColors />
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            
            <Route path="/" element={<DashboardLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="products" element={<Products />} />
              <Route path="devices" element={<Devices />} />
              <Route path="services" element={<Services />} />
              <Route path="blog" element={<Blog />} />
              <Route path="requests" element={<Requests />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="profile" element={<Profile />} />
              <Route path="activity" element={<ActivityLogs />} />
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
