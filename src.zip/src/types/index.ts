export interface Device {
  id: string;
  name: string;
  image: string;
  descriptionEn: string;
  descriptionAr: string;
  specs: string;
  status: 'active' | 'inactive';
  category: string;
  createdAt: string;
}

export interface Service {
  id: string;
  titleEn: string;
  titleAr: string;
  slug: string;
  descriptionEn: string;
  descriptionAr: string;
  features: string[];
  benefits: string[];
  order: number;
  metaTitle: string;
  metaDescription: string;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  image: string;
  category: string;
  tags: string[];
  status: 'draft' | 'published';
  author: string;
  createdAt: string;
}

export interface Request {
  id: string;
  type: 'demo' | 'contact';
  name: string;
  email: string;
  phone: string;
  message: string;
  status: 'new' | 'contacted' | 'closed';
  createdAt: string;
}

export interface Notification {
  id: string;
  type: 'request' | 'contact' | 'alert';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  adminName: string;
  action: string;
  target: string;
  timestamp: string;
}

export interface Category {
  id: number;
  name_ar: string;
  name_en: string;
  slug: string;
}

export interface Subcategory {
  id: number;
  category_id: number;
  parent_id: number | null;
  name_ar: string;
  name_en: string;
  slug: string;
}

export interface Product {
  id?: number;
  name: string;
  category_id: number | '';
  subcategory_id: number | '';
  child_subcategory_id: number | '';
  weight: string;
  sku: string;
  mpn: string;
  gtin: string;
  price?: number | '';
  cost_price?: number | '';
  reduced_price?: number | '';
  max_qty_per_customer: number | '';
  subtitle: string;
  promo_title: string;
  brand?: string;
  description: string;
  image_url: string;
  seo_title: string;
  seo_url: string;
  seo_description: string;
  requires_shipping: boolean;
  is_quantity_determined: boolean;
  show_in_store: boolean;
  attach_file: boolean;
  allow_notes: boolean;
  display_channels?: {
    meta: boolean;
    google: boolean;
    snapchat: boolean;
    tiktok: boolean;
  };
  category_name?: string;
  subcategory_name?: string;
  created_at?: string;
}

