import { Category, Subcategory, Product } from '../types';

export const MOCK_CATEGORIES: Category[] = [
  { id: 1, name_ar: 'جهاز تتبع مركبات', name_en: 'Vehicle Tracking Device', slug: 'vehicle-tracking' },
  { id: 2, name_ar: 'كاميرات ارمكو', name_en: 'Aramco Cameras', slug: 'aramco-cameras' },
  { id: 3, name_ar: 'فلاش كام', name_en: 'Flash Cam', slug: 'flash-cam' },
];

export const MOCK_SUBCATEGORIES: Subcategory[] = [
  // Subcategories for Category 1 (جهاز تتبع مركبات)
  { id: 1, category_id: 1, parent_id: null, name_ar: 'شخصي', name_en: 'Personal', slug: 'personal' },
  { id: 2, category_id: 1, parent_id: 1, name_ar: 'سلكي', name_en: 'Wired', slug: 'wired' },
  { id: 3, category_id: 1, parent_id: 1, name_ar: 'لاسلكي', name_en: 'Wireless', slug: 'wireless' },
  { id: 4, category_id: 1, parent_id: 1, name_ar: 'OBD', name_en: 'OBD', slug: 'obd' },
  { id: 5, category_id: 1, parent_id: null, name_ar: 'هيئة نقل تعليمي', name_en: 'Educational Transport Authority', slug: 'educational-transport' },
  { id: 6, category_id: 1, parent_id: null, name_ar: 'نقل متخصص', name_en: 'Specialized Transport', slug: 'specialized-transport' },
  { id: 7, category_id: 1, parent_id: null, name_ar: 'دراجات نارية', name_en: 'Motorcycles', slug: 'motorcycles' },
  { id: 8, category_id: 1, parent_id: null, name_ar: 'تعليمي', name_en: 'Educational', slug: 'educational' },

  // Subcategories for Category 3 (فلاش كام)
  { id: 9, category_id: 3, parent_id: null, name_ar: 'لايف', name_en: 'Live', slug: 'live' },
  { id: 10, category_id: 3, parent_id: null, name_ar: 'تسجيل', name_en: 'Recording', slug: 'recording' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'جهاز تتبع سلكي GT06',
    category_id: 1,
    subcategory_id: 1,
    child_subcategory_id: 2,
    weight: '0.2',
    sku: 'TRK-001',
    mpn: 'MPN-GT06',
    gtin: 'GTIN-12345',
    max_qty_per_customer: 5,
    subtitle: 'تتبع دقيق للمركبات',
    promo_title: 'الأكثر مبيعاً',
    description: 'جهاز تتبع مركبات سلكي متطور يدعم التنبيهات اللحظية.',
    image_url: 'https://picsum.photos/seed/tracker1/400/400',
    seo_title: 'جهاز تتبع GT06',
    seo_url: 'gt06-tracker',
    seo_description: 'أفضل جهاز تتبع مركبات سلكي في السعودية',
    requires_shipping: true,
    is_quantity_determined: true,
    show_in_store: true,
    attach_file: false,
    allow_notes: true,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: 'كاميرا ارمكو الذكية',
    category_id: 2,
    subcategory_id: '',
    child_subcategory_id: '',
    weight: '1.5',
    sku: 'CAM-ARM-01',
    mpn: 'MPN-ARMCO',
    gtin: 'GTIN-67890',
    max_qty_per_customer: 2,
    subtitle: 'مراقبة عالية الدقة',
    promo_title: 'جديد',
    description: 'كاميرا مراقبة متوافقة مع معايير ارمكو للأمن والسلامة.',
    image_url: 'https://picsum.photos/seed/camera1/400/400',
    seo_title: 'كاميرا ارمكو',
    seo_url: 'aramco-camera',
    seo_description: 'كاميرات مراقبة معتمدة من ارمكو',
    requires_shipping: true,
    is_quantity_determined: false,
    show_in_store: true,
    attach_file: true,
    allow_notes: true,
    created_at: new Date().toISOString(),
  },
];
